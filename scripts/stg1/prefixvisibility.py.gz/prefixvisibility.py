# -*- coding: utf-8 -*-
"""
Created on Mon Jul  9 12:26:36 2018

@author: asemwal
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Jul  5 01:35:45 2018

@author: asemwal
"""
import time
import sys
import utils
stats = {}
"""
print(time.time())
purpose='prefixvisibility'
location='/home/asemwal/raw_data/'
year='2014/'
f=sys.argv[1]
file = open(location+year+f, 'r')
l = str(file.readline()).strip()
while(str(l).strip() !=''):
    x = str(l).split("|");
    k=utils.getKey(x, [4,5,6,10,7])
    try:
        if x[1]  in ('R','A'):
            stats[k] = 1
    except IndexError as e:
        print(l)
        pass
    except KeyError as e:
        stats.update({k:0})
    l = file.readline()
line=""
print(time.time())
while(True):
    try:
        x = stats.popitem()
        line += str(x[0])+"\n"
    except KeyError as e:
        break;
out = open(location+year+'proc/'+purpose+'_'+utils.getTimeStamp(f), 'w')
out.write(line)
out.flush()
out.close()
"""